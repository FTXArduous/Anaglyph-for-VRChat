using UnityEngine;

namespace Anaglyph
{
    [ExecuteAlways]
    [RequireComponent(typeof(Camera))]
    public class DualEyeAnaglyphComposer : MonoBehaviour
    {
        public enum OutputMode { MonoAnaglyph, SeparateLeftRight }
        public OutputMode outputMode = OutputMode.MonoAnaglyph;
        public float ipdMeters = 0.064f; // approximate human IPD
        [Range(0f, 1f)] public float ipdScale = 1.0f; // scale separation for comfort
        [Range(0f, 1f)] public float redWeight = 1.0f;
        [Range(0f, 1f)] public float cyanWeight = 1.0f;

        public Shader composeShader;
        private Material _composeMat;

        private Camera _main;
        private Camera _leftCam;
        private Camera _rightCam;
        [HideInInspector] public RenderTexture leftRT;
        [HideInInspector] public RenderTexture rightRT;

        void OnEnable()
        {
            _main = GetComponent<Camera>();
            EnsureCameras();
            if (composeShader == null)
                composeShader = Shader.Find("Anaglyph/Anaglyph_Compose");
            if (composeShader != null) _composeMat = new Material(computeSafeShader(composeShader));
            SyncCameraSettings();
        }

        Shader computeSafeShader(Shader s) { return s; }

        void EnsureCameras()
        {
            if (_leftCam == null)
            {
                var goL = new GameObject("_AnaglyphLeftCam");
                goL.transform.SetParent(transform, false);
                _leftCam = goL.AddComponent<Camera>();
                _leftCam.enabled = false;
            }
            if (_rightCam == null)
            {
                var goR = new GameObject("_AnaglyphRightCam");
                goR.transform.SetParent(transform, false);
                _rightCam = goR.AddComponent<Camera>();
                _rightCam.enabled = false;
            }
        }

        void SyncCameraSettings()
        {
            if (_main == null || _leftCam == null || _rightCam == null) return;
            CopyCamera(_main, _leftCam);
            CopyCamera(_main, _rightCam);
            _leftCam.depthTextureMode |= DepthTextureMode.Depth;
            _rightCam.depthTextureMode |= DepthTextureMode.Depth;
        }

        void CopyCamera(Camera src, Camera dst)
        {
            dst.fieldOfView = src.fieldOfView;
            dst.nearClipPlane = src.nearClipPlane;
            dst.farClipPlane = src.farClipPlane;
            dst.clearFlags = src.clearFlags;
            dst.backgroundColor = src.backgroundColor;
            dst.cullingMask = src.cullingMask;
            dst.orthographic = src.orthographic;
            dst.orthographicSize = src.orthographicSize;
        }

        void AllocateRTs(int w, int h)
        {
            var fmt = RenderTextureFormat.Default;
            if (leftRT == null || leftRT.width != w || leftRT.height != h)
            {
                ReleaseRTs();
                leftRT = new RenderTexture(w, h, 16, fmt);
                leftRT.name = "_AnaglyphLeftRT";
                rightRT = new RenderTexture(w, h, 16, fmt);
                rightRT.name = "_AnaglyphRightRT";
            }
        }

        void ReleaseRTs()
        {
            if (leftRT) { if (Application.isPlaying) Destroy(leftRT); else DestroyImmediate(leftRT); }
            if (rightRT) { if (Application.isPlaying) Destroy(rightRT); else DestroyImmediate(rightRT); }
            leftRT = null; rightRT = null;
        }

        void OnDisable()
        {
            ReleaseRTs();
            if (_composeMat) { if (Application.isPlaying) Destroy(_composeMat); else DestroyImmediate(_composeMat); }
            if (_leftCam) { if (Application.isPlaying) Destroy(_leftCam.gameObject); else DestroyImmediate(_leftCam.gameObject); }
            if (_rightCam) { if (Application.isPlaying) Destroy(_rightCam.gameObject); else DestroyImmediate(_rightCam.gameObject); }
        }

        void OnRenderImage(RenderTexture src, RenderTexture dst)
        {
            if (_composeMat == null) { Graphics.Blit(src, dst); return; }

            var w = src.width; var h = src.height;
            AllocateRTs(w, h);

            float separation = ipdMeters * ipdScale;
            Vector3 right = transform.right;
            _leftCam.transform.position = transform.position - right * (separation * 0.5f);
            _rightCam.transform.position = transform.position + right * (separation * 0.5f);
            _leftCam.transform.rotation = transform.rotation;
            _rightCam.transform.rotation = transform.rotation;

            _leftCam.targetTexture = leftRT;
            _rightCam.targetTexture = rightRT;

            _leftCam.Render();
            _rightCam.Render();

            if (outputMode == OutputMode.MonoAnaglyph)
            {
                _composeMat.SetTexture("_LeftTex", leftRT);
                _composeMat.SetTexture("_RightTex", rightRT);
                _composeMat.SetFloat("_RedWeight", redWeight);
                _composeMat.SetFloat("_CyanWeight", cyanWeight);
                Graphics.Blit(src, dst, _composeMat);
            }
            else
            {
                // Separate outputs mode: do not overwrite main output. Just pass-through src.
                // leftRT/rightRT are available to bind to in-world screens/materials.
                Graphics.Blit(src, dst);
            }
        }
    }
}
