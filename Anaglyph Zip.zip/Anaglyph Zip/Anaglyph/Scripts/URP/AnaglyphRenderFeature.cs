// This file compiles only when URP is present.
#if UNITY_RENDER_PIPELINE_UNIVERSAL
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;

namespace Anaglyph.URP
{
    public class AnaglyphRenderFeature : ScriptableRendererFeature
    {
        [System.Serializable]
        public class Settings
        {
            public Shader shader;
            [Range(0.0f, 5.0f)] public float lateralShiftPixels = 1.0f;
            [Range(0.0f, 1.0f)] public float redWeight = 1.0f;
            [Range(0.0f, 1.0f)] public float cyanWeight = 1.0f;
            [Range(0.0f, 1.0f)] public float depthTintStrength = 0.25f;
            public RenderPassEvent renderPassEvent = RenderPassEvent.AfterRendering;
        }

        class AnaglyphPass : ScriptableRenderPass
        {
            private Material _mat;
            private Settings _settings;
            private RTHandle _source;

            public AnaglyphPass(Settings settings)
            {
                _settings = settings;
                if (_settings.shader == null)
                {
                    _settings.shader = Shader.Find("Anaglyph/Anaglyph_URP");
                }
                if (_settings.shader != null)
                {
                    _mat = CoreUtils.CreateEngineMaterial(_settings.shader);
                }
            }

            public void Setup(RTHandle source)
            {
                _source = source;
            }

            public override void Execute(ScriptableRenderContext context, ref RenderingData renderingData)
            {
                if (_mat == null) return;

                var cmd = CommandBufferPool.Get("AnaglyphPass");

                _mat.SetFloat("_LateralShiftPixels", _settings.lateralShiftPixels);
                _mat.SetFloat("_RedWeight", _settings.redWeight);
                _mat.SetFloat("_CyanWeight", _settings.cyanWeight);
                _mat.SetFloat("_DepthTintStrength", _settings.depthTintStrength);

                var source = _source;
                var desc = renderingData.cameraData.cameraTargetDescriptor;
                RenderingUtils.ReAllocateIfNeeded(ref source, desc, name: "_AnaglyphSource");

                Blit(cmd, renderingData.cameraData.renderer.cameraColorTargetHandle, renderingData.cameraData.renderer.cameraColorTargetHandle, _mat);

                context.ExecuteCommandBuffer(cmd);
                CommandBufferPool.Release(cmd);
            }
        }

        public Settings settings = new Settings();
        private AnaglyphPass _pass;

        public override void Create()
        {
            _pass = new AnaglyphPass(settings);
            _pass.renderPassEvent = settings.renderPassEvent;
        }

        public override void AddRenderPasses(ScriptableRenderer renderer, ref RenderingData renderingData)
        {
            _pass.Setup(renderer.cameraColorTargetHandle);
            renderer.EnqueuePass(_pass);
        }
    }
}
#else
// Fallback stub to avoid compile errors when URP isn't installed.
namespace Anaglyph.URP { public class AnaglyphRenderFeature : UnityEngine.ScriptableObject { } }
#endif
