using UnityEngine;

namespace Anaglyph
{
    // Drag this GameObject into your scene; it will attach the chosen effect to the main/player camera.
    public class AnaglyphAutoAttach : MonoBehaviour
    {
        public enum Mode { BuiltinSinglePass, URPSinglePass, DualEyeMono, DualEyeSeparate }
        public Mode mode = Mode.BuiltinSinglePass;

        [Header("Common Params")]
        [Range(0f, 5f)] public float lateralShiftPixels = 1.0f;
        [Range(0f, 1f)] public float redWeight = 1.0f;
        [Range(0f, 1f)] public float cyanWeight = 1.0f;
        [Range(0f, 1f)] public float depthTintStrength = 0.2f;

        [Header("Dual Eye Params")]
        public float ipdMeters = 0.064f;
        [Range(0f, 1f)] public float ipdScale = 0.75f;

        void Start()
        {
            var cam = Camera.main;
            if (cam == null)
            {
                var cams = FindObjectsOfType<Camera>();
                if (cams.Length > 0) cam = cams[0];
            }
            if (cam == null) { Debug.LogWarning("AnaglyphAutoAttach: No camera found."); return; }

            // Auto-select when XR/HMD detected (general Unity projects). In VRChat worlds, XR detection is not available.
            if (AutoDetectXRHeadset())
            {
                // Prefer dual-eye modes when HMD detected; default to Separate for flexibility.
                if (mode == Mode.BuiltinSinglePass || mode == Mode.URPSinglePass)
                {
                    mode = Mode.DualEyeSeparate;
                }
            }

            switch (mode)
            {
                case Mode.BuiltinSinglePass:
                    var effect = cam.gameObject.GetComponent<AnaglyphCameraEffect>();
                    if (effect == null) effect = cam.gameObject.AddComponent<AnaglyphCameraEffect>();
                    effect.lateralShiftPixels = lateralShiftPixels;
                    effect.redWeight = redWeight;
                    effect.cyanWeight = cyanWeight;
                    effect.depthTintStrength = depthTintStrength;
                    break;
                case Mode.URPSinglePass:
                    // For URP, prefer renderer feature; however, fallback to camera effect works via OnRenderImage in desktop.
                    var urpEffect = cam.gameObject.GetComponent<AnaglyphCameraEffect>();
                    if (urpEffect == null) urpEffect = cam.gameObject.AddComponent<AnaglyphCameraEffect>();
                    urpEffect.lateralShiftPixels = lateralShiftPixels;
                    urpEffect.redWeight = redWeight;
                    urpEffect.cyanWeight = cyanWeight;
                    urpEffect.depthTintStrength = depthTintStrength;
                    break;
                case Mode.DualEyeMono:
                    var mono = cam.gameObject.GetComponent<DualEyeAnaglyphComposer>();
                    if (mono == null) mono = cam.gameObject.AddComponent<DualEyeAnaglyphComposer>();
                    mono.outputMode = DualEyeAnaglyphComposer.OutputMode.MonoAnaglyph;
                    mono.ipdMeters = ipdMeters;
                    mono.ipdScale = ipdScale;
                    mono.redWeight = redWeight;
                    mono.cyanWeight = cyanWeight;
                    break;
                case Mode.DualEyeSeparate:
                    var sep = cam.gameObject.GetComponent<DualEyeAnaglyphComposer>();
                    if (sep == null) sep = cam.gameObject.AddComponent<DualEyeAnaglyphComposer>();
                    sep.outputMode = DualEyeAnaglyphComposer.OutputMode.SeparateLeftRight;
                    sep.ipdMeters = ipdMeters;
                    sep.ipdScale = ipdScale;
                    sep.redWeight = redWeight;
                    sep.cyanWeight = cyanWeight;
                    break;
            }
        }

        bool AutoDetectXRHeadset()
        {
            // Tries Unity XR Management first, then legacy XR.
            try
            {
                // Prefer XRDisplaySubsystem detection
                var listType = typeof(System.Collections.Generic.List<>).MakeGenericType(System.Type.GetType("UnityEngine.XR.XRDisplaySubsystem, UnityEngine.XRModule"));
                var displays = (System.Collections.IList)System.Activator.CreateInstance(listType);
                var subsystemManager = System.Type.GetType("UnityEngine.SubsystemManager, UnityEngine.CoreModule");
                var getDisplays = subsystemManager.GetMethod("GetInstances", new System.Type[] { listType });
                if (getDisplays != null)
                {
                    getDisplays.Invoke(null, new object[] { displays });
                    foreach (var d in displays)
                    {
                        var runningProp = d.GetType().GetProperty("running");
                        if (runningProp != null && (bool)runningProp.GetValue(d))
                        {
                            return true;
                        }
                    }
                }
                // Fallback: XRSettings.enabled if available
                var xrSettingsType = System.Type.GetType("UnityEngine.XR.XRSettings, UnityEngine.XRModule");
                if (xrSettingsType != null)
                {
                    var enabledProp = xrSettingsType.GetProperty("enabled");
                    if (enabledProp != null)
                    {
                        var enabled = (bool)enabledProp.GetValue(null);
                        if (enabled) return true;
                    }
                }
            }
            catch {}
            return false;
        }
    }
}
