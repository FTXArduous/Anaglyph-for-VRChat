using UnityEngine;

namespace Anaglyph
{
    [ExecuteAlways]
    public class DepthMaterialTint : MonoBehaviour
    {
        public Camera referenceCamera;
        [Range(0f, 1f)] public float tintStrength = 0.25f;
        public Color nearTint = new Color(1f, 0f, 0f, 0f); // attenuate cyan near
        public Color farTint = new Color(0f, 1f, 1f, 0f);  // attenuate red far
        public string colorProperty = "_Color"; // common PBR uses base color

        private Renderer _renderer;
        private MaterialPropertyBlock _mpb;

        void OnEnable()
        {
            _renderer = GetComponent<Renderer>();
            if (referenceCamera == null)
            {
                referenceCamera = Camera.main;
            }
            _mpb = new MaterialPropertyBlock();
        }

        void LateUpdate()
        {
            if (_renderer == null || referenceCamera == null) return;

            var bounds = _renderer.bounds;
            float dist = Vector3.Distance(referenceCamera.transform.position, bounds.center);
            float depth01 = Mathf.InverseLerp(0.5f, 50f, dist);
            var tint = Color.Lerp(nearTint, farTint, depth01) * tintStrength;

            _renderer.GetPropertyBlock(_mpb);
            if (_renderer.sharedMaterial != null && _renderer.sharedMaterial.HasProperty(colorProperty))
            {
                var baseColor = _renderer.sharedMaterial.GetColor(colorProperty);
                var newColor = new Color(
                    baseColor.r * (1f - tint.g - tint.b),
                    baseColor.g * (1f - tint.r),
                    baseColor.b * (1f - tint.r)
                );
                _mpb.SetColor(colorProperty, newColor);
                _renderer.SetPropertyBlock(_mpb);
            }
        }
    }
}
