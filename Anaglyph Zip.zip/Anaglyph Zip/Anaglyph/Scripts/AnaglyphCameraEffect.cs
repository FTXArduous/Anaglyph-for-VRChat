using UnityEngine;

namespace Anaglyph
{
    [ExecuteAlways]
    [RequireComponent(typeof(Camera))]
    public class AnaglyphCameraEffect : MonoBehaviour
    {
        [Range(0.0f, 5.0f)] public float lateralShiftPixels = 1.0f;
        [Range(0.0f, 1.0f)] public float redWeight = 1.0f;
        [Range(0.0f, 1.0f)] public float cyanWeight = 1.0f;
        [Range(0.0f, 1.0f)] public float depthTintStrength = 0.25f;

        public Shader builtinShader;
        private Material _mat;
        private Camera _cam;

        void OnEnable()
        {
            _cam = GetComponent<Camera>();
            if (builtinShader == null)
            {
                builtinShader = Shader.Find("Anaglyph/Anaglyph_Builtin");
            }
            if (builtinShader != null)
            {
                _mat = new Material(builtinShader);
            }
            if (_cam != null)
            {
                _cam.depthTextureMode |= DepthTextureMode.Depth;
            }
        }

        void OnDisable()
        {
            if (_mat != null)
            {
                if (Application.isPlaying) Destroy(_mat); else DestroyImmediate(_mat);
            }
        }

        void OnRenderImage(RenderTexture src, RenderTexture dst)
        {
            if (_mat == null)
            {
                Graphics.Blit(src, dst);
                return;
            }

            _mat.SetFloat("_LateralShiftPixels", lateralShiftPixels);
            _mat.SetFloat("_RedWeight", redWeight);
            _mat.SetFloat("_CyanWeight", cyanWeight);
            _mat.SetFloat("_DepthTintStrength", depthTintStrength);

            Graphics.Blit(src, dst, _mat);
        }
    }
}
