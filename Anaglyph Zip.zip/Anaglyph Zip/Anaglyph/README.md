Anaglyph Plugin for Unity (VRChat Worlds)

Overview
- Provides a thin lateral color filter anaglyph post-process tailored for the player's FOV camera.
- Applies red/cyan channel separation with per-pixel offset and optional depth-aware material tinting.
- Supports Unity Built-in Render Pipeline and URP with separate implementations.
 - Designed for VRChat worlds: use world cameras/screens, not the client HMD cameras.

Features
- Thin pixel lateral shift per-channel to produce anaglyph effect.
- Depth-aware material tint: adjusts material contribution based on camera depth to improve perceived separation.
- Simple C# components to attach to your player camera in VRChat worlds.

Compatibility Notes (VRChat)
- VRChat uses Unity 2019/2021 and a restricted scripting subset; post-processing via shaders is allowed, but some image effects may be limited on Quest/Android. Prefer URP-compatible shaders for best performance if your project uses URP.
- Avoid unsupported native plugins. This package is pure C#/Shader.
- For desktop VRChat, Built-in pipeline effects are fine; for Quest, stick to lightweight settings.

Installation
1. Copy the `Assets/Anaglyph` folder into your Unity project.
2. If you use URP, enable the Anaglyph Renderer Feature in the URP Renderer asset.
3. Non-VRChat projects: add `AnaglyphCameraEffect` to your camera.
4. VRChat worlds: drag `AnaglyphAutoAttach` into your scene and choose a mode for a world camera or screen pipeline.

Where to drag-and-drop `AnaglyphAutoAttach`
- Create an empty GameObject at the root of your scene (e.g., `AnaglyphSetup`).
- Add the `AnaglyphAutoAttach` component to that GameObject.
- Set `Mode`:
	- `BuiltinSinglePass`: attaches `AnaglyphCameraEffect` to your chosen world camera.
	- `DualEyeMono`: attaches `DualEyeAnaglyphComposer` to your chosen world camera and outputs a mono anaglyph (for screens).
	- `DualEyeSeparate`: attaches `DualEyeAnaglyphComposer` and exposes `leftRT`/`rightRT` for two in-world screens.
- In VRChat, pick or create a world camera to drive a RenderTexture or screen; the client/HMD camera cannot be modified.

Usage
- Attach `AnaglyphCameraEffect` to the camera used for player view.
- Tweak parameters: `lateralShiftPixels`, `depthTintStrength`, `redWeight`, `cyanWeight`.
- For URP, add the `AnaglyphRenderFeature` to your Renderer Data and enable the pass.

VRChat Usage Patterns
- Client/HMD cameras are not script-accessible; do not rely on modifying them.
- Recommended approaches:
	- World Display (separate outputs): Use `DualEyeAnaglyphComposer` with `SeparateLeftRight` and assign `leftRT`/`rightRT` to two in-world quads or UI `RawImage`s.
	- Mono Anaglyph Screen: Use `DualEyeAnaglyphComposer` with `MonoAnaglyph` on a world camera that renders to a screen.
	- Simple Filter on World Camera: Use `AnaglyphCameraEffect` on a world camera feeding a custom mirror/display.

Performance Tips
- Keep `lateralShiftPixels` low (0.5–2 px) to maintain clarity.
- Consider disabling depth tinting on low-end devices.
- Use single-pass stereo carefully; the effect operates on the final color buffer.
- Quest-friendly defaults: use `AnaglyphAutoAttach` with `BuiltinSinglePass` or `DualEyeSeparate`, keep RT sizes modest, and avoid stacking heavy post effects.
 - For VRChat Quest, prefer `SeparateLeftRight` with half-resolution RTs and simple materials.

Limitations
- True per-eye stereo rendering for anaglyph requires dual renders; this plugin approximates via channel offsets and depth tint in a single pass.
- Material auto-tint is heuristic; ensure your materials use standard PBR for best results.

Files
- `Shaders/Anaglyph_Builtin.shader`: Image effect shader for Built-in pipeline.
- `Shaders/Anaglyph_URP.shader`: Fullscreen pass shader for URP.
- `Scripts/AnaglyphCameraEffect.cs`: MonoBehaviour to drive the effect.
- `Scripts/URP/AnaglyphRenderFeature.cs`: URP renderer feature.
- `Scripts/DepthMaterialTint.cs`: Optional component to auto-adjust materials by depth.

How It Works
- The shader samples the source texture twice with a small horizontal offset: left channels (R) and right channels (G+B as Cyan).
- Depth texture is sampled to compute a normalized depth factor that slightly tints materials (by adjusting their contribution) based on distance.
- Parameters let you balance color weights and offsets to match your desired FOV and comfort.

VRChat Setup Notes
- Place the effect on your `MainCamera` or the camera controlling the player's view.
- Ensure `DepthTexture` is enabled (Built-in: camera depth; URP: Depth Texture in pipeline settings).
- Test on desktop and Quest separately; some shaders need mobile-friendly precision.

License
- Provided as-is for personal/world use.

Additional Files (Dual-Eye)
- `Shaders/Anaglyph_Compose.shader`: Composes left/right eye renders into an anaglyph.
- `Scripts/DualEyeAnaglyphComposer.cs`: Renders with two hidden cameras (left/right) and composes.

Dual-Eye Option (Mono output)
- Instead of lateral shifting one render, enable true dual-eye composition:
	1. Add `DualEyeAnaglyphComposer` to the player camera (do not add `AnaglyphCameraEffect` at the same time).
	2. Set `ipdMeters` (~0.064) and `ipdScale` (0–1) to control separation.
	3. The script creates two hidden cameras offset horizontally, renders to RTs, then uses `Anaglyph_Compose` to merge R from left and G+B from right.
	4. Use when targeting flat-screen anaglyph viewing (not VR HMD). In VRChat, apply this on a world camera output to a screen.

Dual-Eye Option (Separate outputs)
- If you want two distinct renders without mono composition:
	1. In `DualEyeAnaglyphComposer`, set `outputMode = SeparateLeftRight`.
	2. Access `leftRT` and `rightRT` from the component to drive in-world screens/materials.
	3. The main camera output remains unchanged; you decide how/where to present left/right images.
	4. For Quest, consider half-resolution RTs to reduce fill-rate; you can modify `AllocateRTs` to allocate `w/2, h/2` and scale quads appropriately.

HMD Note
- For VR HMDs, anaglyph mono output is not suitable for in-headset viewing; use the single-pass lateral filter on a world display, or output to camera mirrors/screens. The dual-eye composer is intended for non-HMD displays.
 - VRChat client cameras are not manipulatable from world scripts; use your own world cameras or render textures.

URP Setup (step-by-step)
- Install URP via Package Manager and switch your project to URP (create URP Asset, assign in Graphics settings).
- Open your URP Renderer Data asset and add `AnaglyphRenderFeature`.
- Ensure "Depth Texture" is enabled in the URP Asset for accurate depth tint.
- Use `AnaglyphAutoAttach` with `URPSinglePass` for quick camera-based application, or rely on the Renderer Feature for pipeline-integrated post-process.
- The URP shader `Hidden/Anaglyph/Anaglyph_URP` is guarded to import cleanly even if URP isn't active; full functionality requires URP.

Auto-detect HMD behavior
- `AnaglyphAutoAttach` attempts to detect if an HMD/XR is present in general Unity projects.
- If XR is detected and your mode is a single-pass filter, it will switch to `DualEyeSeparate` by default so you can route per-eye outputs to screens.
- In VRChat worlds, XR detection and client camera control are not available; choose modes manually and use world cameras/screens.
